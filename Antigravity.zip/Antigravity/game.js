/**
 * Factor Diner Craze - Core Game Engine
 * 專為國小高年級學生打造的滿版美式餐廳因數料理闖關遊戲
 */

// ==================== 1. 資料庫與題目配置 ====================

// 美式經典美食清單 (American Diner Dishes)
const DISH_DATABASE = [
  { id: 'burger_classic', name: '特製雙層起司純牛堡', icon: '🍔', desc: '手打安格斯純牛肉，淋上香濃美式融化切達起司' },
  { id: 'burger_bacon', name: '巨無霸煙燻培根怪獸堡', icon: '🍔', desc: '厚煎雙層肉排搭上香脆煙燻培根與秘製BBQ醬' },
  { id: 'hotdog_chili', name: '德州辣肉醬熱狗堡', icon: '🌭', desc: '道地美式香腸配上滿滿墨西哥辣椒肉醬' },
  { id: 'fries_golden', name: '黃金特脆波浪薯條', icon: '🍟', desc: '剛起油鍋金黃酥脆，撒上大蒜香料海鹽' },
  { id: 'pizza_pepperoni', name: '美式臘腸重乳酪披薩', icon: '🍕', desc: '道地紐約薄脆餅皮，牽絲濃郁摩佐羅拉起司' },
  { id: 'shake_strawberry', name: '紐約特濃草莓厚奶昔', icon: '🥤', desc: '頂層擠滿香甜鮮奶油與糖漬紅草莓' },
  { id: 'chicken_bbq', name: '南方針焰脆皮炸雞', icon: '🍗', desc: '美式香料醃製，外皮咔滋咔滋酥脆作響' },
  { id: 'donut_glazed', name: '美式糖霜七彩甜甜圈', icon: '🍩', desc: '淋上滑順巧克力甘納許與七彩糖針' },
  { id: 'pancake_stack', name: '楓糖奶油美式鬆餅塔', icon: '🥞', desc: '層層疊疊的香軟鬆餅，融化金黃奶油塊' },
  { id: 'onion_rings', name: '德州酥脆洋蔥圈塔', icon: '🧅', desc: '金黃酥脆的手切炸洋蔥圈，搭配蜂蜜芥末醬' },
  { id: 'ribs_bbq', name: '美式秘製炭烤豬肋排', icon: '🍖', desc: '炭烤焦香多汁，刷滿經典BBQ烤肉醬' },
  { id: 'cheesecake', name: '紐約經典重乳酪蛋糕', icon: '🍰', desc: '濃郁奶香與香脆全麥餅乾底的完美結合' }
];

// 漢堡食材層層堆疊圖標庫
const BURGER_LAYERS = ['🍞', '🥩', '🧀', '🥬', '🍅', '🥓', '🥒', '🧅', '🍳', '🍞'];

// 顧客角色庫
const CUSTOMER_PROFILES = [
  { name: '飢餓的牛仔', avatar: '🤠' },
  { name: '滑板酷男孩', avatar: '🛹' },
  { name: '活力啦啦隊長', avatar: '🎀' },
  { name: '美食評論家', avatar: '🧐' },
  { name: '重機巡警隊長', avatar: '👮' },
  { name: '爵士樂吉他手', avatar: '🎷' },
  { name: '公路旅行冒險家', avatar: '🚗' },
  { name: '棒球強棒打者', avatar: '⚾' }
];

// 三大關卡設定 (難度一關比一關高，全部1~100以內)
const LEVEL_CONFIG = {
  1: {
    id: 1,
    name: '街邊經典快餐車',
    targetCoins: 1200,
    starThresholds: [600, 900, 1200],
    orderCount: 7,
    basePatienceSeconds: 45,
    // 數字池：因數少、較簡單 (6 ~ 25，混合合數與質數)
    numberPool: [6, 8, 9, 10, 12, 14, 15, 16, 18, 20, 21, 24, 25, 7, 11, 13, 17, 19]
  },
  2: {
    id: 2,
    name: '霓虹美式漢堡館',
    targetCoins: 2000,
    starThresholds: [1000, 1500, 2000],
    orderCount: 8,
    basePatienceSeconds: 36,
    // 數字池：中等因數合數 (24 ~ 60，因數 6~10 個)
    numberPool: [24, 28, 30, 32, 36, 40, 42, 45, 48, 50, 54, 56, 60, 64, 29, 31, 37]
  },
  3: {
    id: 3,
    name: '米其林美式旗艦餐酒館',
    targetCoins: 3200,
    starThresholds: [1600, 2400, 3200],
    orderCount: 9,
    basePatienceSeconds: 30,
    // 數字池：高難度超多因數巨獸 (60, 72, 84, 90, 96, 100) 與 陷阱數字 (51=3x17, 57=3x19, 87=3x29, 91=7x13)
    numberPool: [60, 72, 84, 90, 96, 100, 51, 57, 87, 91, 93, 95, 68, 76, 78, 88]
  }
};

// 升級配置
const UPGRADE_CONFIG = {
  patience: {
    name: '高級保溫台',
    maxLevel: 3,
    baseCost: 300,
    costMultiplier: 1.6,
    effectPerLevel: 5
  },
  coinMulti: {
    name: '大廚小費翻倍罐',
    maxLevel: 3,
    baseCost: 500,
    costMultiplier: 1.8,
    effectPerLevel: 0.3
  },
  hintDiscount: {
    name: '智能因數食譜',
    maxLevel: 3,
    baseCost: 400,
    costMultiplier: 1.5,
    effectPerLevel: 5
  },
  comboBoost: {
    name: '招牌美式辣醬',
    maxLevel: 3,
    baseCost: 600,
    costMultiplier: 1.7,
    effectPerLevel: 0.25
  }
};

// ==================== 2. 因數計算與彩虹對演算法 ====================

function getFactors(n) {
  const factors = [];
  for (let i = 1; i <= Math.sqrt(n); i++) {
    if (n % i === 0) {
      factors.push(i);
      if (i !== n / i) {
        factors.push(n / i);
      }
    }
  }
  return factors.sort((a, b) => a - b);
}

function getFactorRainbowPairs(n) {
  const pairs = [];
  for (let i = 1; i <= Math.sqrt(n); i++) {
    if (n % i === 0) {
      pairs.push([i, n / i]);
    }
  }
  return pairs;
}

// ==================== 3. 遊戲狀態管理 (Game State) ====================

class GameStateManager {
  constructor() {
    this.storageKey = 'factor_diner_craze_v2';
    this.data = this.loadData();
  }

  getDefaultData() {
    return {
      coins: 300,
      levels: {
        1: { stars: 0, highscore: 0 },
        2: { stars: 0, highscore: 0 },
        3: { stars: 0, highscore: 0 }
      },
      upgrades: {
        patience: 0,
        coinMulti: 0,
        hintDiscount: 0,
        comboBoost: 0
      },
      puzzlePieces: [false, false, false],
      unlockedDishes: ['burger_classic', 'fries_golden'],
      missedStats: {
        91: { count: 3, pairs: '7 × 13 (常被誤認成質數)' },
        51: { count: 3, pairs: '3 × 17 (漏掉 3 的倍數判斷)' },
        87: { count: 2, pairs: '3 × 29' },
        57: { count: 2, pairs: '3 × 19' },
        36: { count: 1, pairs: '漏掉 6 或是 4 × 9' },
        48: { count: 1, pairs: '漏掉 3 × 16' }
      },
      leaderboard: [
        { name: '漢堡大亨小明', score: 3680, stars: 3, level: 3, date: '2026-10-01' },
        { name: '神廚小美', score: 2850, stars: 3, level: 2, date: '2026-10-02' },
        { name: '快餐飛人阿傑', score: 1420, stars: 3, level: 1, date: '2026-10-03' }
      ]
    };
  }

  loadData() {
    try {
      const saved = localStorage.getItem(this.storageKey);
      if (saved) {
        return Object.assign(this.getDefaultData(), JSON.parse(saved));
      }
    } catch (e) {
      console.warn('載入存檔失敗，使用初始設定:', e);
    }
    return this.getDefaultData();
  }

  saveData() {
    try {
      localStorage.setItem(this.storageKey, JSON.stringify(this.data));
    } catch (e) {
      console.error('儲存進度失敗:', e);
    }
  }

  addCoins(amount) {
    this.data.coins += Math.round(amount);
    if (this.data.coins < 0) this.data.coins = 0;
    this.saveData();
    this.renderHUDCoins();
  }

  renderHUDCoins() {
    const el = document.getElementById('hud-session-coins');
    if (el) {
      el.textContent = this.data.coins.toLocaleString();
    }
  }

  recordMissed(number, detail = '') {
    if (!this.data.missedStats[number]) {
      this.data.missedStats[number] = { count: 0, pairs: detail };
    }
    this.data.missedStats[number].count += 1;
    this.saveData();
  }
}

const state = new GameStateManager();

// ==================== 4. 遊戲核心主控制器 (Game Controller) ====================

class GameApp {
  constructor() {
    this.currentView = 'view-home';
    this.activeLevel = 1;
    this.sessionCoins = 0;
    this.currentOrderIndex = 0;
    this.currentOrder = null;
    this.orderTimer = null;
    this.orderTimeLeft = 0;
    this.orderTimeTotal = 0;
    this.lives = 3;
    this.combo = 0;
    this.maxCombo = 0;
    this.completedOrders = 0;
    this.sessionMissed = [];
    this.orderStartTime = 0;

    // 特效畫布
    this.canvas = document.getElementById('effects-canvas');
    this.ctx = this.canvas.getContext('2d');
    this.particles = [];
    this.setupCanvas();

    this.bindEvents();
    this.updateUIFromState();
  }

  setupCanvas() {
    const resize = () => {
      this.canvas.width = window.innerWidth;
      this.canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', resize);
    resize();

    const loop = () => {
      this.updateParticles();
      requestAnimationFrame(loop);
    };
    requestAnimationFrame(loop);
  }

  spawnCoinExplosion(x, y, count = 30) {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 9 + 4;
      this.particles.push({
        x: x || window.innerWidth / 2,
        y: y || window.innerHeight / 2,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 6,
        gravity: 0.35,
        size: Math.random() * 16 + 12,
        text: Math.random() > 0.3 ? '🪙' : '✨',
        opacity: 1,
        life: 1,
        decay: Math.random() * 0.015 + 0.01
      });
    }
  }

  updateParticles() {
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx;
      p.y += p.vy;
      p.vy += p.gravity;
      p.life -= p.decay;

      if (p.life <= 0) {
        this.particles.splice(i, 1);
        continue;
      }

      this.ctx.save();
      this.ctx.globalAlpha = p.life;
      this.ctx.font = `${p.size}px sans-serif`;
      this.ctx.fillText(p.text, p.x, p.y);
      this.ctx.restore();
    }
  }

  switchView(viewId) {
    document.querySelectorAll('.game-view').forEach(view => {
      view.classList.remove('active');
    });
    const target = document.getElementById(viewId);
    if (target) {
      target.classList.add('active');
      this.currentView = viewId;
    }
    window.audio.playClick();
  }

  bindEvents() {
    // 頂部導航按鈕
    document.getElementById('btn-sound-toggle').addEventListener('click', () => {
      const enabled = window.audio.toggleSound();
      document.getElementById('btn-sound-toggle').textContent = enabled ? '🔊' : '🔇';
    });

    document.getElementById('btn-music-toggle').addEventListener('click', () => {
      const enabled = window.audio.toggleMusic();
      document.getElementById('btn-music-toggle').textContent = enabled ? '🎵' : '🔇';
    });

    // 全螢幕切換 (F11 或點擊按鈕)
    document.getElementById('btn-toggle-fullscreen').addEventListener('click', () => {
      this.toggleFullScreen();
    });

    // 暫停 / 返回選單按鈕
    document.getElementById('btn-hud-home').addEventListener('click', () => {
      this.stopGameTimer();
      this.renderLevelSelect();
      this.switchView('view-level-select');
    });

    // 頂部垃圾桶跳過按鈕 (花費金幣)
    document.getElementById('btn-trash-skip').addEventListener('click', () => {
      if (this.currentView === 'view-gameplay') {
        this.skipOrder();
      }
    });

    // 主首頁按鈕
    document.getElementById('btn-start-game').addEventListener('click', () => {
      this.renderLevelSelect();
      this.switchView('view-level-select');
      window.audio.startBGM();
    });

    document.getElementById('btn-open-shop').addEventListener('click', () => {
      this.renderShop();
      this.switchView('view-shop');
    });

    document.getElementById('btn-open-puzzle').addEventListener('click', () => {
      this.renderPuzzle();
      this.switchView('view-puzzle');
    });

    document.getElementById('btn-open-gallery').addEventListener('click', () => {
      this.renderGallery();
      this.switchView('view-gallery');
    });

    document.getElementById('btn-open-leaderboard').addEventListener('click', () => {
      this.renderLeaderboard();
      this.switchView('view-leaderboard');
    });

    // 玩法小教室彈窗
    const modal = document.getElementById('modal-how-to-play');
    document.getElementById('btn-how-to-play').addEventListener('click', () => {
      modal.classList.add('active');
      window.audio.playClick();
    });
    document.getElementById('btn-close-modal').addEventListener('click', () => {
      modal.classList.remove('active');
    });
    document.getElementById('btn-close-modal-bottom').addEventListener('click', () => {
      modal.classList.remove('active');
    });

    // 視圖返回
    document.getElementById('btn-back-from-level').addEventListener('click', () => {
      this.switchView('view-home');
    });
    document.getElementById('btn-back-from-shop').addEventListener('click', () => {
      this.switchView('view-home');
    });
    document.getElementById('btn-back-from-puzzle').addEventListener('click', () => {
      this.switchView('view-home');
    });
    document.getElementById('btn-back-from-gallery').addEventListener('click', () => {
      this.switchView('view-home');
    });
    document.getElementById('btn-back-from-leaderboard').addEventListener('click', () => {
      this.switchView('view-home');
    });

    // 結算畫面按鈕
    document.getElementById('btn-replay-level').addEventListener('click', () => {
      this.startLevel(this.activeLevel);
    });
    document.getElementById('btn-next-level').addEventListener('click', () => {
      if (this.activeLevel < 3) {
        this.startLevel(this.activeLevel + 1);
      } else {
        this.switchView('view-puzzle');
      }
    });
    document.getElementById('btn-settle-home').addEventListener('click', () => {
      this.renderLevelSelect();
      this.switchView('view-level-select');
    });

    // 關卡進入按鈕
    document.querySelectorAll('.btn-play-level').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const lvl = parseInt(e.currentTarget.getAttribute('data-level'), 10);
        this.startLevel(lvl);
      });
    });

    // 因數輸入與送出
    const factorInput = document.getElementById('factor-input');
    const submitBtn = document.getElementById('btn-submit-factor');

    submitBtn.addEventListener('click', () => {
      this.handleFactorSubmit();
    });

    factorInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        this.handleFactorSubmit();
      }
    });

    // 提示按鈕
    document.getElementById('btn-use-hint').addEventListener('click', () => {
      this.useHint();
    });

    // 收銀機數字鍵盤 (POS Numpad)
    document.querySelectorAll('.num-key').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const key = e.currentTarget.getAttribute('data-key');
        window.audio.playClick();
        if (key === 'clear') {
          factorInput.value = '';
        } else if (key === 'enter') {
          this.handleFactorSubmit();
        } else {
          factorInput.value += key;
        }
        factorInput.focus();
      });
    });

    // 升級按鈕
    document.querySelectorAll('.btn-buy-upgrade').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const type = btn.getAttribute('data-upgrade');
        this.buyUpgrade(type);
      });
    });

    // 排行榜標籤切換
    document.querySelectorAll('.tab-btn').forEach(tab => {
      tab.addEventListener('click', (e) => {
        document.querySelectorAll('.tab-btn').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));

        tab.classList.add('active');
        const targetId = tab.getAttribute('data-tab');
        document.getElementById(targetId).classList.add('active');
        window.audio.playClick();
      });
    });
  }

  toggleFullScreen() {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().catch(() => {});
      }
    }
  }

  updateUIFromState() {
    state.renderHUDCoins();
    this.renderLevelSelect();
  }

  // ==================== 5. 關卡選擇 ====================

  renderLevelSelect() {
    const lvl1Stars = state.data.levels[1].stars;
    const lvl2Stars = state.data.levels[2].stars;

    for (let l = 1; l <= 3; l++) {
      const data = state.data.levels[l];
      const starsContainer = document.getElementById(`level-${l}-stars`);
      const highscoreEl = document.getElementById(`level-${l}-highscore`);

      if (starsContainer) {
        let starStr = '';
        for (let s = 1; s <= 3; s++) {
          starStr += s <= data.stars ? '<span class="star-icon star-active">★</span>' : '<span class="star-icon">☆</span>';
        }
        starsContainer.innerHTML = starStr;
      }

      if (highscoreEl) {
        highscoreEl.textContent = `最高紀錄：${data.highscore.toLocaleString()} 金幣`;
      }
    }

    const card2 = document.getElementById('level-card-2');
    const btn2 = card2.querySelector('.btn-play-level');
    if (lvl1Stars >= 3) {
      card2.classList.remove('locked');
      btn2.disabled = false;
    } else {
      card2.classList.add('locked');
      btn2.disabled = true;
    }

    const card3 = document.getElementById('level-card-3');
    const btn3 = card3.querySelector('.btn-play-level');
    if (lvl2Stars >= 3) {
      card3.classList.remove('locked');
      btn3.disabled = false;
    } else {
      card3.classList.add('locked');
      btn3.disabled = true;
    }
  }

  getUpgradeValue(type) {
    const lvl = state.data.upgrades[type] || 0;
    const conf = UPGRADE_CONFIG[type];
    return lvl * conf.effectPerLevel;
  }

  // ==================== 6. 開始關卡與訂單產生 ====================

  startLevel(levelId) {
    this.activeLevel = levelId;
    const config = LEVEL_CONFIG[levelId];
    this.sessionCoins = 0;
    this.currentOrderIndex = 0;
    this.lives = 3;
    this.combo = 0;
    this.maxCombo = 0;
    this.completedOrders = 0;
    this.sessionMissed = [];

    this.levelNumbers = [...config.numberPool].sort(() => Math.random() - 0.5);

    document.getElementById('hud-stage-name').textContent = `第 ${levelId} 關：${config.name}`;
    this.updateHUDProgress();
    this.renderLives();

    this.switchView('view-gameplay');
    this.nextOrder();
  }

  renderLives() {
    const container = document.getElementById('hud-lives-box');
    let hearts = '';
    for (let i = 0; i < 3; i++) {
      hearts += i < this.lives ? '<span class="hud-heart">❤️</span>' : '<span class="hud-heart lost" style="filter: grayscale(1); opacity: 0.3;">🖤</span>';
    }
    container.innerHTML = hearts;
  }

  nextOrder() {
    this.stopGameTimer();
    const config = LEVEL_CONFIG[this.activeLevel];

    if (this.currentOrderIndex >= config.orderCount) {
      this.finishLevel();
      return;
    }

    this.currentOrderIndex++;
    document.getElementById('bubble-order-counter').textContent = `訂單 ${this.currentOrderIndex} / ${config.orderCount}`;

    const targetNum = this.levelNumbers[(this.currentOrderIndex - 1) % this.levelNumbers.length];
    const allFactors = getFactors(targetNum);
    const rainbowPairs = getFactorRainbowPairs(targetNum);

    const dish = DISH_DATABASE[Math.floor(Math.random() * DISH_DATABASE.length)];
    const customer = CUSTOMER_PROFILES[Math.floor(Math.random() * CUSTOMER_PROFILES.length)];

    this.currentOrder = {
      targetNumber: targetNum,
      allFactors: allFactors,
      foundFactors: new Set(),
      dish: dish,
      customer: customer,
      rainbowPairs: rainbowPairs
    };

    this.orderStartTime = Date.now();

    // 更新顧客與氣泡
    document.getElementById('customer-avatar-face').textContent = customer.avatar;
    document.getElementById('customer-name-tag').textContent = customer.name;
    document.getElementById('bubble-dish-icon').textContent = dish.icon;
    document.getElementById('bubble-dish-name').textContent = dish.name;
    document.getElementById('bubble-target-number').textContent = targetNum;

    this.renderFactorBadges();
    this.renderBurgerAssembly();

    const input = document.getElementById('factor-input');
    input.value = '';
    input.focus();

    let hintPrice = 20 - this.getUpgradeValue('hintDiscount');
    if (hintPrice < 5) hintPrice = 5;
    document.getElementById('hint-cost').textContent = hintPrice;

    const patienceBonus = this.getUpgradeValue('patience');
    this.orderTimeTotal = config.basePatienceSeconds + patienceBonus;
    this.orderTimeLeft = this.orderTimeTotal;
    this.startOrderTimer();

    if (!state.data.unlockedDishes.includes(dish.id)) {
      state.data.unlockedDishes.push(dish.id);
      state.saveData();
    }
  }

  // 渲染因數數字牌 (由小到大排好，問號代表缺漏)
  renderFactorBadges() {
    const grid = document.getElementById('factors-badges-grid');
    const { allFactors, foundFactors } = this.currentOrder;
    grid.innerHTML = '';

    allFactors.forEach(factor => {
      const badge = document.createElement('div');
      badge.className = 'factor-pill-badge';

      if (foundFactors.has(factor)) {
        badge.classList.add('found');
        badge.textContent = factor;
      } else {
        badge.classList.add('missing');
        badge.textContent = '?';
      }
      grid.appendChild(badge);
    });

    document.getElementById('bubble-found-count').textContent = foundFactors.size;
    document.getElementById('bubble-total-count').textContent = allFactors.length;
  }

  // 渲染漢堡層層堆疊
  renderBurgerAssembly() {
    const stack = document.getElementById('burger-assembly-stack');
    const { allFactors, foundFactors } = this.currentOrder;
    stack.innerHTML = '';

    // 底層麵包
    const bottomBun = document.createElement('div');
    bottomBun.className = 'food-layer';
    bottomBun.textContent = '🍞';
    stack.appendChild(bottomBun);

    const count = foundFactors.size;
    for (let i = 0; i < count; i++) {
      const layer = document.createElement('div');
      layer.className = 'food-layer';
      const icon = BURGER_LAYERS[(i + 1) % (BURGER_LAYERS.length - 1)];
      layer.textContent = icon;
      stack.appendChild(layer);
    }

    if (count === allFactors.length && count > 0) {
      const topBun = document.createElement('div');
      topBun.className = 'food-layer';
      topBun.textContent = '🍞🚩';
      stack.appendChild(topBun);
    }
  }

  startOrderTimer() {
    const fill = document.getElementById('bubble-patience-fill');
    const tickInterval = 100;

    this.orderTimer = setInterval(() => {
      this.orderTimeLeft -= 0.1;
      const pct = Math.max(0, (this.orderTimeLeft / this.orderTimeTotal) * 100);
      fill.style.width = `${pct}%`;

      if (pct > 50) {
        fill.style.backgroundColor = '#22c55e';
      } else if (pct > 25) {
        fill.style.backgroundColor = '#f59e0b';
      } else {
        fill.style.backgroundColor = '#ef4444';
      }

      if (this.orderTimeLeft <= 0) {
        this.handleOrderTimeout();
      }
    }, tickInterval);
  }

  stopGameTimer() {
    if (this.orderTimer) {
      clearInterval(this.orderTimer);
      this.orderTimer = null;
    }
  }

  // ==================== 7. 輸入判定與暴賺出餐 ====================

  handleFactorSubmit() {
    const input = document.getElementById('factor-input');
    const val = parseInt(input.value.trim(), 10);
    input.value = '';

    if (isNaN(val) || val <= 0) {
      this.showToast('請輸入 1~100 的正整數喔！', 'warn');
      window.audio.playWrong();
      input.focus();
      return;
    }

    const { targetNumber, allFactors, foundFactors } = this.currentOrder;

    if (foundFactors.has(val)) {
      this.showToast(`配料【${val}】已經加過囉！`, 'warn');
      window.audio.playWrong();
      input.focus();
      return;
    }

    if (allFactors.includes(val)) {
      foundFactors.add(val);
      window.audio.playCorrectIngredient();

      // 每找對一個因數獎勵 15 金幣
      state.addCoins(15);
      this.showToast(`✨ 成功加入因數配料【${val}】！(+15 🪙)`, 'success');
      this.renderFactorBadges();
      this.renderBurgerAssembly();

      if (foundFactors.size === allFactors.length) {
        this.completeOrder();
      }
    } else {
      window.audio.playWrong();
      this.combo = 0;
      this.updateComboUI();
      this.showToast(`哎呀！${targetNumber} 不能被 ${val} 整除喔！`, 'error');

      state.recordMissed(targetNumber, `誤填 ${val}`);
      if (!this.sessionMissed.find(m => m.number === targetNumber)) {
        this.sessionMissed.push({
          number: targetNumber,
          pairs: this.currentOrder.rainbowPairs,
          factors: allFactors
        });
      }
    }
    input.focus();
  }

  useHint() {
    const { allFactors, foundFactors, targetNumber } = this.currentOrder;
    let hintPrice = 20 - this.getUpgradeValue('hintDiscount');
    if (hintPrice < 5) hintPrice = 5;

    if (state.data.coins < hintPrice) {
      this.showToast(`金幣不足！提示需要 ${hintPrice} 金幣`, 'warn');
      window.audio.playWrong();
      return;
    }

    const remaining = allFactors.filter(f => !foundFactors.has(f));
    if (remaining.length === 0) return;

    state.addCoins(-hintPrice);
    window.audio.playClick();

    const revealed = remaining[Math.floor(Math.random() * remaining.length)];
    const mate = targetNumber / revealed;

    this.showToast(`💡 大廚秘訣：${revealed} × ${mate} = ${targetNumber}！試試填入 ${revealed} 吧！`, 'info');

    if (!this.sessionMissed.find(m => m.number === targetNumber)) {
      this.sessionMissed.push({
        number: targetNumber,
        pairs: this.currentOrder.rainbowPairs,
        factors: allFactors
      });
    }
  }

  skipOrder() {
    const penalty = 50;
    if (state.data.coins < penalty) {
      this.showToast(`金幣不足，無法放棄（需 ${penalty} 金幣）`, 'warn');
      window.audio.playWrong();
      return;
    }

    state.addCoins(-penalty);
    window.audio.playAnger();
    this.combo = 0;
    this.updateComboUI();

    this.showToast(`已放棄訂單！扣除 ${penalty} 🪙，換下一位客人`, 'error');
    this.stopGameTimer();

    setTimeout(() => {
      this.nextOrder();
    }, 700);
  }

  // 滿意出餐！金幣暴賺！
  completeOrder() {
    this.stopGameTimer();
    this.completedOrders++;
    this.combo++;
    if (this.combo > this.maxCombo) this.maxCombo = this.combo;
    this.updateComboUI();

    window.audio.playOrderComplete();

    const { allFactors, targetNumber } = this.currentOrder;
    const baseReward = 90 + allFactors.length * 20;
    const timeBonus = Math.round(this.orderTimeLeft * 3.5);
    const comboMulti = 1 + (this.combo - 1) * (0.25 + this.getUpgradeValue('comboBoost'));
    const coinBoostMulti = 1 + this.getUpgradeValue('coinMulti');

    const totalEarned = Math.round((baseReward + timeBonus) * comboMulti * coinBoostMulti);

    this.sessionCoins += totalEarned;
    state.addCoins(totalEarned);

    this.spawnCoinExplosion(window.innerWidth / 2, window.innerHeight * 0.45, 35);
    this.showToast(`🛎️ 完美出餐！暴賺 +${totalEarned} 🪙（連擊 ${this.combo}x 加成！）`, 'success');

    this.updateHUDProgress();

    const elapsedSeconds = (Date.now() - this.orderStartTime) / 1000;
    if (elapsedSeconds > 22 && !this.sessionMissed.find(m => m.number === targetNumber)) {
      this.sessionMissed.push({
        number: targetNumber,
        pairs: this.currentOrder.rainbowPairs,
        factors: allFactors
      });
    }

    setTimeout(() => {
      this.nextOrder();
    }, 1100);
  }

  handleOrderTimeout() {
    this.stopGameTimer();
    window.audio.playAnger();

    this.lives--;
    this.renderLives();
    this.combo = 0;
    this.updateComboUI();

    const penalty = 30;
    state.addCoins(-penalty);

    const { targetNumber, allFactors, rainbowPairs } = this.currentOrder;
    state.recordMissed(targetNumber, '超時未完成');
    if (!this.sessionMissed.find(m => m.number === targetNumber)) {
      this.sessionMissed.push({
        number: targetNumber,
        pairs: rainbowPairs,
        factors: allFactors
      });
    }

    this.showToast(`⏰ 客人等太久氣走！失去 ❤️ 且 -${penalty} 🪙`, 'error');

    if (this.lives <= 0) {
      setTimeout(() => {
        this.gameOver();
      }, 1000);
    } else {
      setTimeout(() => {
        this.nextOrder();
      }, 1200);
    }
  }

  gameOver() {
    this.stopGameTimer();
    alert('😭 今日餐廳愛心耗盡，營業失敗！不要氣餒，升級保溫台增加時間再來挑戰！');
    this.switchView('view-level-select');
  }

  updateComboUI() {
    const banner = document.getElementById('kitchen-combo-banner');
    const mult = document.getElementById('combo-multiplier');
    if (this.combo > 1) {
      banner.style.display = 'block';
      mult.textContent = this.combo;
    } else {
      banner.style.display = 'none';
    }
  }

  showToast(msg) {
    const toast = document.getElementById('kitchen-toast-msg');
    toast.textContent = msg;
    clearTimeout(this.toastTimer);
    this.toastTimer = setTimeout(() => {
      toast.textContent = '';
    }, 2400);
  }

  updateHUDProgress() {
    const config = LEVEL_CONFIG[this.activeLevel];
    const fill = document.getElementById('hud-progress-fill');
    const text = document.getElementById('hud-progress-text');

    const pct = Math.min(100, (this.sessionCoins / config.targetCoins) * 100);
    fill.style.width = `${pct}%`;
    text.textContent = `${this.sessionCoins.toLocaleString()} / ${config.targetCoins.toLocaleString()}`;

    const s1 = document.getElementById('hud-star-1');
    const s2 = document.getElementById('hud-star-2');
    const s3 = document.getElementById('hud-star-3');

    s1.classList.toggle('achieved', this.sessionCoins >= config.starThresholds[0]);
    s2.classList.toggle('achieved', this.sessionCoins >= config.starThresholds[1]);
    s3.classList.toggle('achieved', this.sessionCoins >= config.starThresholds[2]);
  }

  // ==================== 8. 結算與教學檢討 ====================

  finishLevel() {
    this.stopGameTimer();
    const config = LEVEL_CONFIG[this.activeLevel];

    let starsEarned = 0;
    if (this.sessionCoins >= config.starThresholds[2]) starsEarned = 3;
    else if (this.sessionCoins >= config.starThresholds[1]) starsEarned = 2;
    else if (this.sessionCoins >= config.starThresholds[0]) starsEarned = 1;

    const prevData = state.data.levels[this.activeLevel];
    if (starsEarned > prevData.stars) prevData.stars = starsEarned;
    if (this.sessionCoins > prevData.highscore) prevData.highscore = this.sessionCoins;

    if (starsEarned >= 3) {
      state.data.puzzlePieces[this.activeLevel - 1] = true;
    }

    state.saveData();

    document.getElementById('res-coins').textContent = `+${this.sessionCoins.toLocaleString()} 🪙`;
    document.getElementById('res-completed').textContent = `${this.completedOrders} / ${config.orderCount} 道`;
    document.getElementById('res-combo').textContent = `${this.maxCombo} COMBO 🔥`;

    const puzzleStatusEl = document.getElementById('res-puzzle-status');
    if (starsEarned >= 3) {
      puzzleStatusEl.textContent = `🧩 碎片 #${this.activeLevel} 已入手！`;
      puzzleStatusEl.style.color = '#10b981';
      window.audio.playVictory();
      this.spawnCoinExplosion(window.innerWidth / 2, window.innerHeight * 0.35, 50);
    } else {
      puzzleStatusEl.textContent = `未達 3 星（未解鎖碎片）`;
      puzzleStatusEl.style.color = '#ef4444';
      window.audio.playOrderComplete();
    }

    for (let s = 1; s <= 3; s++) {
      const starEl = document.getElementById(`result-star-${s}`);
      starEl.classList.toggle('star-active', s <= starsEarned);
    }

    const subtitle = document.getElementById('settlement-subtitle');
    const nextBtn = document.getElementById('btn-next-level');

    if (starsEarned === 3) {
      subtitle.textContent = this.activeLevel < 3 ? '🎉 太厲害了！榮獲 3 顆星！已解鎖下一關營業許可！' : '👑 傳奇誕生！你已通關全部關卡，成為全美第一神廚！';
      nextBtn.style.display = 'inline-flex';
      nextBtn.textContent = this.activeLevel < 3 ? '⏩ 前往下一關！' : '🏆 查看榮譽壁畫！';
    } else {
      subtitle.textContent = `獲得 ${starsEarned} 顆星！需要 3 顆星才能解鎖下一關，繼續加油！`;
      nextBtn.style.display = 'none';
    }

    this.renderLearningReview();

    state.data.leaderboard.push({
      name: '你（大廚）',
      score: this.sessionCoins,
      stars: starsEarned,
      level: this.activeLevel,
      date: new Date().toISOString().split('T')[0]
    });
    state.data.leaderboard.sort((a, b) => b.score - a.score);
    if (state.data.leaderboard.length > 10) state.data.leaderboard.pop();
    state.saveData();

    this.switchView('view-settlement');
  }

  renderLearningReview() {
    const list = document.getElementById('review-factors-list');
    list.innerHTML = '';

    let reviewItems = [...this.sessionMissed];
    if (reviewItems.length === 0) {
      const pool = LEVEL_CONFIG[this.activeLevel].numberPool;
      const sample = pool.slice(0, 3);
      reviewItems = sample.map(n => ({
        number: n,
        pairs: getFactorRainbowPairs(n),
        factors: getFactors(n)
      }));
    }

    reviewItems.forEach(item => {
      const card = document.createElement('div');
      card.className = 'review-number-card';

      let pairsHtml = item.pairs.map(p => `<span class="pair-chip">${p[0]} × ${p[1]} = ${item.number}</span>`).join(' ');
      let allFactorsHtml = item.factors.map(f => `<span class="factor-mini-badge">${f}</span>`).join(' ');

      card.innerHTML = `
        <div style="display:flex; justify-content:space-between; margin-bottom:4px;">
          <strong style="color:var(--diner-gold); font-size:16px;">題目：${item.number}</strong>
          <span style="font-size:12px;">共 ${item.factors.length} 個因數</span>
        </div>
        <div style="font-size:12px; margin-bottom:4px;">
          🌈 <strong>乘積彩虹對：</strong> ${pairsHtml}
        </div>
        <div style="font-size:12px;">
          ✅ <strong>完整因數：</strong> ${allFactorsHtml}
        </div>
      `;
      list.appendChild(card);
    });
  }

  // ==================== 9. 商鋪、拼圖、圖鑑、排行 ====================

  renderShop() {
    for (const [key, conf] of Object.entries(UPGRADE_CONFIG)) {
      const currentLvl = state.data.upgrades[key] || 0;
      const lvlEl = document.getElementById(`lvl-${key}`);
      const costEl = document.getElementById(`cost-${key}`);
      const btn = document.querySelector(`.btn-buy-upgrade[data-upgrade="${key}"]`);

      if (lvlEl) lvlEl.textContent = `等級：Lv. ${currentLvl} / ${conf.maxLevel}`;

      if (currentLvl >= conf.maxLevel) {
        if (costEl) costEl.textContent = '已升至滿級！';
        if (btn) btn.disabled = true;
      } else {
        const cost = Math.round(conf.baseCost * Math.pow(conf.costMultiplier, currentLvl));
        if (costEl) costEl.textContent = `${cost.toLocaleString()} 🪙`;
        if (btn) btn.disabled = state.data.coins < cost;
      }
    }
  }

  buyUpgrade(type) {
    const conf = UPGRADE_CONFIG[type];
    const currentLvl = state.data.upgrades[type] || 0;
    if (currentLvl >= conf.maxLevel) return;

    const cost = Math.round(conf.baseCost * Math.pow(conf.costMultiplier, currentLvl));
    if (state.data.coins < cost) {
      alert('金幣不足！多去餐廳完成幾道料理賺金幣吧！');
      window.audio.playWrong();
      return;
    }

    state.addCoins(-cost);
    state.data.upgrades[type] = currentLvl + 1;
    state.saveData();

    window.audio.playUpgradeSuccess();
    this.spawnCoinExplosion(window.innerWidth / 2, window.innerHeight / 2, 25);
    this.renderShop();
  }

  renderPuzzle() {
    const pieces = state.data.puzzlePieces;
    let unlockedCount = 0;

    for (let i = 1; i <= 3; i++) {
      const pieceEl = document.getElementById(`puzzle-piece-${i}`);
      if (pieces[i - 1]) {
        pieceEl.classList.remove('locked');
        unlockedCount++;
      } else {
        pieceEl.classList.add('locked');
      }
    }

    document.getElementById('puzzle-pieces-count').textContent = unlockedCount;

    const masterpiece = document.getElementById('masterpiece-banner');
    if (unlockedCount === 3) {
      masterpiece.classList.add('show');
      window.audio.playVictory();
      this.spawnCoinExplosion(window.innerWidth / 2, window.innerHeight * 0.4, 60);
    } else {
      masterpiece.classList.remove('show');
    }
  }

  renderGallery() {
    const grid = document.getElementById('food-gallery-grid');
    grid.innerHTML = '';

    DISH_DATABASE.forEach(dish => {
      const isUnlocked = state.data.unlockedDishes.includes(dish.id);
      const card = document.createElement('div');
      card.className = `food-gallery-card ${isUnlocked ? 'unlocked' : 'locked'}`;

      card.innerHTML = `
        <div class="food-icon-wrap">${isUnlocked ? dish.icon : '❓'}</div>
        <h4 class="food-name">${isUnlocked ? dish.name : '神秘美饌'}</h4>
        <p class="food-desc">${isUnlocked ? dish.desc : '通關營業時完成此料理訂單即可解鎖！'}</p>
        <div class="food-status-badge">${isUnlocked ? '✨ 已收錄食譜' : '🔒 尚未解鎖'}</div>
      `;
      grid.appendChild(card);
    });
  }

  renderLeaderboard() {
    const rankList = document.getElementById('rank-list');
    rankList.innerHTML = '';

    state.data.leaderboard.forEach((item, index) => {
      const row = document.createElement('div');
      row.className = `rank-row rank-${index + 1}`;
      const medal = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : `#${index + 1}`;

      row.innerHTML = `
        <div class="rank-pos">${medal}</div>
        <div class="rank-user">
          <div style="font-weight:bold;">${item.name}</div>
          <div style="font-size:12px; color:#94a3b8;">關卡 ${item.level} ・ ${'★'.repeat(item.stars)}</div>
        </div>
        <div class="rank-score">${item.score.toLocaleString()} 🪙</div>
      `;
      rankList.appendChild(row);
    });

    const missedGrid = document.getElementById('missed-rank-grid');
    missedGrid.innerHTML = '';

    const sortedMissed = Object.entries(state.data.missedStats)
      .map(([num, info]) => ({ number: parseInt(num, 10), count: info.count, pairs: info.pairs }))
      .sort((a, b) => b.count - a.count);

    sortedMissed.slice(0, 10).forEach((item, idx) => {
      const card = document.createElement('div');
      card.className = 'missed-rank-card';
      const factors = getFactors(item.number);

      card.innerHTML = `
        <div class="missed-card-header">
          <span>TOP ${idx + 1} 易錯陷阱</span>
          <span>數字：${item.number}</span>
          <span style="font-size:12px; color:#f87171; margin-left:auto;">卡關 ${item.count} 次</span>
        </div>
        <div style="font-size:12px; margin-top:4px;">
          ⚠️ <strong>常見失誤：</strong> ${item.pairs || '忘記不是質數，或漏掉了中間因數對'}
        </div>
        <div style="font-size:12px; color:#6ee7b7; margin-top:2px;">
          🌈 <strong>完整正解：</strong> [ ${factors.join(', ')} ]
        </div>
      `;
      missedGrid.appendChild(card);
    });
  }
}

window.addEventListener('DOMContentLoaded', () => {
  window.game = new GameApp();
});
