@echo off
set "TARGET=%~dp0index.html"

start msedge --app="file:///%TARGET%" --start-maximized 2>nul
if %errorlevel% equ 0 exit

start chrome --app="file:///%TARGET%" --start-maximized 2>nul
if %errorlevel% equ 0 exit

start "" "%TARGET%"
exit
