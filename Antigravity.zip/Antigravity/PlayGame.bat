@echo off
set "TARGET=%~dp0index.html"

:: Try launching Microsoft Edge in standalone app mode
start msedge --app="file:///%TARGET%" --start-maximized 2>nul
if %errorlevel% equ 0 exit

:: Try Google Chrome
start chrome --app="file:///%TARGET%" --start-maximized 2>nul
if %errorlevel% equ 0 exit

:: Default Browser fallback
start "" "%TARGET%"
exit
