/**
 * Factor Diner Audio Engine
 * 使用 Web Audio API 原生合成所有音效 (SFX) 與美式復古餐廳背景音樂 (BGM)
 * 免外部音檔依賴，保證隨時隨地 100% 穩定發聲
 */

class SoundEngine {
  constructor() {
    this.ctx = null;
    this.soundEnabled = true;
    this.musicEnabled = true;
    this.bgmPlaying = false;
    this.bgmTimer = null;
    this.currentStep = 0;
    this.masterGain = null;
    this.sfxGain = null;
    this.musicGain = null;
  }

  // 使用者互動後初始化 AudioContext (符合現代瀏覽器安全策略)
  init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      this.ctx = new AudioCtx();

      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(0.8, this.ctx.currentTime);
      this.masterGain.connect(this.ctx.destination);

      this.sfxGain = this.ctx.createGain();
      this.sfxGain.gain.setValueAtTime(0.85, this.ctx.currentTime);
      this.sfxGain.connect(this.masterGain);

      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.setValueAtTime(0.35, this.ctx.currentTime);
      this.musicGain.connect(this.masterGain);
    }

    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  toggleSound() {
    this.soundEnabled = !this.soundEnabled;
    return this.soundEnabled;
  }

  toggleMusic() {
    this.musicEnabled = !this.musicEnabled;
    if (this.musicEnabled) {
      this.startBGM();
    } else {
      this.stopBGM();
    }
    return this.musicEnabled;
  }

  // 1. 按鈕點擊聲（清脆復古收銀鍵）
  playClick() {
    if (!this.soundEnabled) return;
    this.init();
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(520, t);
    osc.frequency.exponentialRampToValueAtTime(180, t + 0.05);

    gain.gain.setValueAtTime(0.3, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + 0.05);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(t);
    osc.stop(t + 0.05);
  }

  // 2. 成功加入正確因數食材（清脆上揚撲咚聲 + 煎肉感）
  playCorrectIngredient() {
    if (!this.soundEnabled) return;
    this.init();
    const t = this.ctx.currentTime;

    // 音符雙階琶音 (高興上揚)
    [523.25, 659.25, 783.99].forEach((freq, idx) => {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const startTime = t + idx * 0.04;

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, startTime);
      osc.frequency.exponentialRampToValueAtTime(freq * 1.2, startTime + 0.1);

      gain.gain.setValueAtTime(0.3, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.12);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(startTime);
      osc.stop(startTime + 0.12);
    });

    // 烹飪滋滋聲微音效
    this.playSizzle(0.12);
  }

  // 滋滋煎肉聲
  playSizzle(duration = 0.3) {
    if (!this.soundEnabled) return;
    this.init();
    const t = this.ctx.currentTime;
    const bufferSize = this.ctx.sampleRate * duration;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);

    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(3200, t);
    filter.Q.setValueAtTime(1.8, t);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.2, t);
    gain.gain.linearRampToValueAtTime(0.01, t + duration);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxGain);

    noise.start(t);
  }

  // 3. 輸入錯誤（不是因數、或已輸入過）
  playWrong() {
    if (!this.soundEnabled) return;
    this.init();
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(180, t);
    osc.frequency.linearRampToValueAtTime(120, t + 0.18);

    gain.gain.setValueAtTime(0.25, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + 0.18);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(t);
    osc.stop(t + 0.18);
  }

  // 4. 料理完成・出餐服務鈴 (Diner Bell: Ding! 🛎️)
  playOrderComplete() {
    if (!this.soundEnabled) return;
    this.init();
    const t = this.ctx.currentTime;

    // 高頻清脆金屬鈴聲 2093Hz (C7) + 泛音
    const osc1 = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(2093, t);

    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(4186, t);

    gain.gain.setValueAtTime(0.5, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.8);

    osc1.connect(gain);
    osc2.connect(gain);
    gain.connect(this.sfxGain);

    osc1.start(t);
    osc2.start(t);
    osc1.stop(t + 0.8);
    osc2.stop(t + 0.8);

    // 隨後伴隨金幣叮噹聲
    setTimeout(() => this.playCoinShimmer(), 150);
  }

  // 5. 金幣狂飆叮鈴鈴 (Coin Cascade)
  playCoinShimmer() {
    if (!this.soundEnabled) return;
    this.init();
    const notes = [987.77, 1174.66, 1318.51, 1567.98, 1760.00, 2093.00];
    notes.forEach((freq, i) => {
      setTimeout(() => {
        if (!this.soundEnabled || !this.ctx) return;
        const t = this.ctx.currentTime;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, t);

        gain.gain.setValueAtTime(0.2, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.15);

        osc.connect(gain);
        gain.connect(this.sfxGain);

        osc.start(t);
        osc.stop(t + 0.15);
      }, i * 45);
    });
  }

  // 6. 客人超時生氣警笛 (Anger Whistle)
  playAnger() {
    if (!this.soundEnabled) return;
    this.init();
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(320, t);
    osc.frequency.linearRampToValueAtTime(140, t + 0.35);

    gain.gain.setValueAtTime(0.35, t);
    gain.gain.linearRampToValueAtTime(0.01, t + 0.35);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(t);
    osc.stop(t + 0.35);
  }

  // 7. 購買升級/解鎖成就 (Fanfare / Jingle)
  playUpgradeSuccess() {
    if (!this.soundEnabled) return;
    this.init();
    const notes = [523.25, 659.25, 783.99, 1046.50];
    notes.forEach((freq, idx) => {
      setTimeout(() => {
        if (!this.soundEnabled || !this.ctx) return;
        const t = this.ctx.currentTime;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, t);

        gain.gain.setValueAtTime(0.3, t);
        gain.gain.exponentialRampToValueAtTime(0.01, t + 0.25);

        osc.connect(gain);
        gain.connect(this.sfxGain);

        osc.start(t);
        osc.stop(t + 0.25);
      }, idx * 70);
    });
  }

  // 8. 三顆星/通關超盛大勝利號角 (Victory Fanfare)
  playVictory() {
    if (!this.soundEnabled) return;
    this.init();
    const chords = [
      { notes: [523.25, 659.25, 783.99], time: 0 },
      { notes: [523.25, 659.25, 783.99], time: 180 },
      { notes: [523.25, 659.25, 783.99], time: 360 },
      { notes: [698.46, 880.00, 1046.50], time: 540 },
      { notes: [783.99, 987.77, 1174.66, 1567.98], time: 900 }
    ];

    chords.forEach(c => {
      setTimeout(() => {
        if (!this.soundEnabled || !this.ctx) return;
        c.notes.forEach(f => {
          const t = this.ctx.currentTime;
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();

          osc.type = 'triangle';
          osc.frequency.setValueAtTime(f, t);

          gain.gain.setValueAtTime(0.25, t);
          gain.gain.exponentialRampToValueAtTime(0.01, t + 0.45);

          osc.connect(gain);
          gain.connect(this.sfxGain);

          osc.start(t);
          osc.stop(t + 0.45);
        });
      }, c.time);
    });
  }

  // 9. 背景音樂 (BGM: 美式復古快餐店輕快 Funk / Swing 循環)
  startBGM() {
    if (!this.musicEnabled) return;
    this.init();
    if (this.bgmPlaying) return;

    this.bgmPlaying = true;
    this.currentStep = 0;

    // 經典美式餐廳四和弦貝斯與切分節奏 (C大調流行放克進行: C - Am - F - G)
    const bassline = [
      130.81, 0, 164.81, 196.00,  // C, -, E, G
      110.00, 0, 130.81, 164.81,  // A, -, C, E
      87.31,  0, 110.00, 130.81,  // F, -, A, C
      98.00,  0, 123.47, 146.83   // G, -, B, D
    ];

    const chords = [
      [523.25, 659.25], null, [523.25, 659.25], null,
      [440.00, 523.25], null, [440.00, 523.25], null,
      [349.23, 440.00], null, [349.23, 440.00], null,
      [392.00, 493.88], null, [392.00, 493.88], null
    ];

    const stepDuration = 180; // 毫秒 per 16分音符，輕快節奏 (約 125 BPM)

    this.bgmTimer = setInterval(() => {
      if (!this.bgmPlaying || !this.musicEnabled || !this.ctx) return;

      const t = this.ctx.currentTime;
      const step = this.currentStep % 16;

      // 貝斯音
      const bFreq = bassline[step];
      if (bFreq > 0) {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(bFreq, t);

        gain.gain.setValueAtTime(0.2, t);
        gain.gain.exponentialRampToValueAtTime(0.005, t + 0.15);

        osc.connect(gain);
        gain.connect(this.musicGain);

        osc.start(t);
        osc.stop(t + 0.15);
      }

      // 和弦切分
      const cNotes = chords[step];
      if (cNotes) {
        cNotes.forEach(freq => {
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();

          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, t);

          gain.gain.setValueAtTime(0.08, t);
          gain.gain.exponentialRampToValueAtTime(0.001, t + 0.12);

          osc.connect(gain);
          gain.connect(this.musicGain);

          osc.start(t);
          osc.stop(t + 0.12);
        });
      }

      // 輕快爵士小鼓/踩鈸節奏
      if (step % 2 === 1) {
        // 踩鈸 Hi-hat
        this.playHiHat(t);
      }

      this.currentStep++;
    }, stepDuration);
  }

  playHiHat(t) {
    if (!this.musicGain || !this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'square';
    osc.frequency.setValueAtTime(8000, t);

    gain.gain.setValueAtTime(0.02, t);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.04);

    osc.connect(gain);
    gain.connect(this.musicGain);

    osc.start(t);
    osc.stop(t + 0.04);
  }

  stopBGM() {
    this.bgmPlaying = false;
    if (this.bgmTimer) {
      clearInterval(this.bgmTimer);
      this.bgmTimer = null;
    }
  }
}

// 建立全域音效單例
window.audio = new SoundEngine();
